/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_SRC_CFGPARSER_OPARSE_H_TMP_INCLUDED
# define YY_YY_SRC_CFGPARSER_OPARSE_H_TMP_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    TOK_SLASH = 258,
    TOK_OPEN = 259,
    TOK_CLOSE = 260,
    TOK_STRING = 261,
    TOK_INTEGER = 262,
    TOK_FLOAT = 263,
    TOK_BOOLEAN = 264,
    TOK_IPV6TYPE = 265,
    TOK_DEBUGLEVEL = 266,
    TOK_IPVERSION = 267,
    TOK_HNA4 = 268,
    TOK_HNA6 = 269,
    TOK_PLUGIN = 270,
    TOK_INTERFACE_DEFAULTS = 271,
    TOK_INTERFACE = 272,
    TOK_NOINT = 273,
    TOK_TOS = 274,
    TOK_OLSRPORT = 275,
    TOK_RTPROTO = 276,
    TOK_RTTABLE = 277,
    TOK_RTTABLE_DEFAULT = 278,
    TOK_RTTABLE_TUNNEL = 279,
    TOK_RTTABLE_PRIORITY = 280,
    TOK_RTTABLE_DEFAULTOLSR_PRIORITY = 281,
    TOK_RTTABLE_TUNNEL_PRIORITY = 282,
    TOK_RTTABLE_DEFAULT_PRIORITY = 283,
    TOK_WILLINGNESS = 284,
    TOK_IPCCON = 285,
    TOK_FIBMETRIC = 286,
    TOK_FIBMETRICDEFAULT = 287,
    TOK_USEHYST = 288,
    TOK_HYSTSCALE = 289,
    TOK_HYSTUPPER = 290,
    TOK_HYSTLOWER = 291,
    TOK_POLLRATE = 292,
    TOK_NICCHGSPOLLRT = 293,
    TOK_TCREDUNDANCY = 294,
    TOK_MPRCOVERAGE = 295,
    TOK_LQ_LEVEL = 296,
    TOK_LQ_FISH = 297,
    TOK_LQ_AGING = 298,
    TOK_LQ_PLUGIN = 299,
    TOK_LQ_NAT_THRESH = 300,
    TOK_LQ_MULT = 301,
    TOK_CLEAR_SCREEN = 302,
    TOK_PLPARAM = 303,
    TOK_MIN_TC_VTIME = 304,
    TOK_LOCK_FILE = 305,
    TOK_USE_NIIT = 306,
    TOK_SMART_GW = 307,
    TOK_SMART_GW_ALWAYS_REMOVE_SERVER_TUNNEL = 308,
    TOK_SMART_GW_USE_COUNT = 309,
    TOK_SMART_GW_TAKEDOWN_PERCENTAGE = 310,
    TOK_SMART_GW_POLICYROUTING_SCRIPT = 311,
    TOK_SMART_GW_EGRESS_IFS = 312,
    TOK_SMART_GW_EGRESS_FILE = 313,
    TOK_SMART_GW_EGRESS_FILE_PERIOD = 314,
    TOK_SMART_GW_STATUS_FILE = 315,
    TOK_SMART_GW_OFFSET_TABLES = 316,
    TOK_SMART_GW_OFFSET_RULES = 317,
    TOK_SMART_GW_ALLOW_NAT = 318,
    TOK_SMART_GW_PERIOD = 319,
    TOK_SMART_GW_STABLECOUNT = 320,
    TOK_SMART_GW_THRESH = 321,
    TOK_SMART_GW_WEIGHT_EXITLINK_UP = 322,
    TOK_SMART_GW_WEIGHT_EXITLINK_DOWN = 323,
    TOK_SMART_GW_WEIGHT_ETX = 324,
    TOK_SMART_GW_DIVIDER_ETX = 325,
    TOK_SMART_GW_UPLINK = 326,
    TOK_SMART_GW_UPLINK_NAT = 327,
    TOK_SMART_GW_SPEED = 328,
    TOK_SMART_GW_PREFIX = 329,
    TOK_SRC_IP_ROUTES = 330,
    TOK_MAIN_IP = 331,
    TOK_SET_IPFORWARD = 332,
    TOK_HOSTLABEL = 333,
    TOK_NETLABEL = 334,
    TOK_MAXIPC = 335,
    TOK_IFMODE = 336,
    TOK_IPV4MULTICAST = 337,
    TOK_IP4BROADCAST = 338,
    TOK_IPV4BROADCAST = 339,
    TOK_IPV6MULTICAST = 340,
    TOK_IPV4SRC = 341,
    TOK_IPV6SRC = 342,
    TOK_IFWEIGHT = 343,
    TOK_HELLOINT = 344,
    TOK_HELLOVAL = 345,
    TOK_TCINT = 346,
    TOK_TCVAL = 347,
    TOK_MIDINT = 348,
    TOK_MIDVAL = 349,
    TOK_HNAINT = 350,
    TOK_HNAVAL = 351,
    TOK_AUTODETCHG = 352,
    TOK_IPV4_ADDR = 353,
    TOK_IPV6_ADDR = 354,
    TOK_DEFAULT = 355,
    TOK_AUTO = 356,
    TOK_NONE = 357,
    TOK_COMMENT = 358
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_SRC_CFGPARSER_OPARSE_H_TMP_INCLUDED  */
